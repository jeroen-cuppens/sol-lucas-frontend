
import { Box, Button, Card, Grid, Paper, TextField, ThemeProvider, Typography, useTheme } from '@mui/material';
import { ThemeLight } from '../theme';
import "../css/login.css";
import { useTranslation } from 'react-i18next';
import { useNavigate } from 'react-router-dom';
import { Password } from '@mui/icons-material';
import { useState } from 'react';
import { useAppDispatch } from '../store/hooks';
import { changePopup } from '../store/slices/popupSlice';
import { popupOpties } from '../common/popupOpties';

function RegisterForm() {
    const theme = useTheme();
    const navigate = useNavigate();
    const { t, i18n } = useTranslation();
    const dispatch = useAppDispatch();

    const [email, setEmail] = useState<string>();
    const [password, setPassword] = useState<string>();
    const [passwordConfirm, setPasswordConfirm] = useState<string>();



    const handleRegister= async () =>{
        try{

            if(password != passwordConfirm){
                dispatch(changePopup({type:popupOpties.error, text:"Passwords do not match."}));
            }else{

                //register
    
                dispatch(changePopup({type:popupOpties.success, text:"Success"}));
    
                navigate('/Home');
            }

        }catch{
            dispatch(changePopup({type:popupOpties.error, text:"Something went wrong."}));
        }

    }


    return (
        <ThemeProvider theme={ThemeLight}>
            <form onSubmit={(e:any)=>{handleRegister();e.preventDefault()}}>
                <Paper className='form'>
                        <p>Register</p>
                        <TextField label="Email" required value={email} onChange={(e:any)=>{setEmail(e.target.value)}}/>
                        <TextField label="password" type='password' required value={password} onChange={(e:any)=>{setPassword(e.target.value)}}/>
                        <TextField label="confirm password" type='password' required value={passwordConfirm} onChange={(e:any)=>{setPasswordConfirm(e.target.value)}}/>
                        <Button variant='contained' type='submit'>Login</Button>
                </Paper>
            </form>
        </ThemeProvider>
    )
}
export default RegisterForm;
