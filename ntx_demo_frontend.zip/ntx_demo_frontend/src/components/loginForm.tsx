
import { Box, Button, Card, Grid, Paper, TextField, ThemeProvider, Typography, useTheme } from '@mui/material';
import { ThemeLight } from '../theme';
import "../css/login.css";
import { useTranslation } from 'react-i18next';
import { useNavigate } from 'react-router-dom';
import { Password } from '@mui/icons-material';
import { useAppDispatch } from '../store/hooks';
import { changePopup } from '../store/slices/popupSlice';
import { popupOpties } from '../common/popupOpties';
import { useState } from 'react';
import { IUser } from '../models/IUser';
import { IRESTService } from '../services';
import { RESTService } from '../services/RESTService';
import { changeCurrentUser } from '../store/slices/currentUserSlice';

function LoginForm() {
    const theme = useTheme();
    const navigate = useNavigate();
    const { t, i18n } = useTranslation();
    const service: IRESTService = new RESTService();
    const dispatch = useAppDispatch();

    const [email, setEmail] = useState<string>("");
    const [password, setPassword] = useState<string>("");



    const handleLogin= async () =>{
        try{
            //authenticate

            var user = await getUser(email);

            if(user != null && user != undefined){
                //dispatch(changeCurrentUser(user));
                localStorage.setItem("user", JSON.stringify(user));
            }else{
                throw new Error('no user')
            }


            dispatch(changePopup({type:popupOpties.success, text:"Success"}));

            navigate('/Home');

        }catch{
            dispatch(changePopup({type:popupOpties.error, text:"Something went wrong."}));
        }

    }

    const getUser = async(email:string) => {
        try{    
            const result:IUser = await service.user.GetUser(email);
            return result
        }catch{
            dispatch(changePopup({type:popupOpties.error, text:"Something went wrong."}));
        }
    }


    return (
        <ThemeProvider theme={ThemeLight}>
            <form onSubmit={(e:any)=>{handleLogin();e.preventDefault()}}>
                <Paper className='form'>
                        <p>Login</p>
                        <TextField label="Email" required value={email} onChange={(e:any)=>{setEmail(e.target.value)}}/>
                        <TextField label="password" type='password' required value={password} onChange={(e:any)=>{setPassword(e.target.value)}}/>
                        <Button variant='contained' type='submit'>Login</Button>
                </Paper>
            </form>
        </ThemeProvider>
    )
}
export default LoginForm;
