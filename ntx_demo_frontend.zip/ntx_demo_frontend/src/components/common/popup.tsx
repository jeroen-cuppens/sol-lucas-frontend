
import {useEffect } from 'react';
import { Alert, Stack } from '@mui/material';
import { popupOpties } from '../../common/popupOpties';
import { useAppDispatch, useAppSelector } from '../../store/hooks';
import { clearPopup } from '../../store/slices/popupSlice';
import "../../css/popup.css";
import { useTranslation } from 'react-i18next';


function Popup() {
  const { t, i18n } = useTranslation();
  const dispatch = useAppDispatch();
  const currentPopup = useAppSelector((state) => state.popUp.currentPopup);


    useEffect(()=>{
        showMsgBar(currentPopup.type);
    },[currentPopup])

    const showMsgBar = (choice:popupOpties) =>{   
        if(choice !== ""){
            setTimeout(() => {
                dispatch(clearPopup());
            }, 4500);
        }
    }
    
    return (
    <Stack className="popup" spacing={1}>
      {
        currentPopup.type === popupOpties.success ? <Alert severity="success">{t(currentPopup.text)}</Alert>
        : currentPopup.type === popupOpties.error ? <Alert severity="error">{t(currentPopup.text)}</Alert>
        : <></>
      }
    </Stack>
    )
}
export default Popup;
