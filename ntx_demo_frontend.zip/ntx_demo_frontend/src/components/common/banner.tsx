import NachtDropLogo from '../../img/NachtDropLogo.png';
import '../../css/banner.css';

import { ThemeDark} from '../../theme';
import { ThemeProvider } from '@emotion/react';
import { useNavigate } from 'react-router-dom';
import { Button, Grid, IconButton, Menu, MenuItem } from '@mui/material';
import { useTranslation } from 'react-i18next';
import LogoutIcon from '@mui/icons-material/Logout';


function Banner() { 
  const navigate = useNavigate();

  const logout = () => {
    localStorage.removeItem('user');
    navigate('/Login');
  }

  return (
    <div className="banner">

      <ThemeProvider theme={ThemeDark}>

        <div className='bannerRight'>
          {Number(window.innerWidth) > 640 ? 
            <Button variant='outlined' onClick={()=>{logout()}}>Logout</Button>
            :
            <IconButton color='primary' onClick={()=>{logout()}}><LogoutIcon/></IconButton>
          }
        </div>

      </ThemeProvider>
    </div>
  )
}
export default Banner;
