
import { Box, Button, Card, Grid, Paper, TextField, ThemeProvider, Typography, useTheme } from '@mui/material';
import { ThemeLight } from '../theme';
import "../css/login.css";
import { useTranslation } from 'react-i18next';
import { useNavigate } from 'react-router-dom';
import { Password } from '@mui/icons-material';
import { useEffect, useState } from 'react';
import { useAppDispatch } from '../store/hooks';
import { changePopup } from '../store/slices/popupSlice';
import { popupOpties } from '../common/popupOpties';
import { IUser } from '../models/IUser';
import { changeCurrentUser } from '../store/slices/currentUserSlice';
import "../css/businessCard.css";


function BusinessCard(props:IUser) {
    const theme = useTheme();
    const navigate = useNavigate();
    const { t, i18n } = useTranslation();
    const dispatch = useAppDispatch();


    return (
        <ThemeProvider theme={ThemeLight}>
            <Paper className='card'>
                <p>Name: {props.name} {props.lastName}</p>
                <p>address: {props.address}</p>
                <p>skills:</p>
                {props.skills.map(function(skill, i){
                    return <p>{skill.skillName}</p>;
                })}
            </Paper>
        </ThemeProvider>
    )
}
export default BusinessCard;
