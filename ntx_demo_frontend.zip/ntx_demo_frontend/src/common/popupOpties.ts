export enum popupOpties{
    none="",
    error="error",
    success="success"
}