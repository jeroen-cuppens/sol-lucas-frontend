import React from 'react';
import logo from './logo.svg';
import './App.css';
import Popup from './components/common/popup';
import { ThemeProvider } from 'styled-components';
import { LocalizationProvider } from '@mui/x-date-pickers';
import { BrowserRouter, Routes, Route } from "react-router-dom"
import Banner from './components/common/banner';
import { ThemeLight } from './theme';
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
import Home from './pages/Home';
import Login from './pages/Login';

function App() {
  return (
    <React.Fragment>
      <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet"></link>
      <Popup/>
      <ThemeProvider theme={ThemeLight}>
        <LocalizationProvider dateAdapter={AdapterDayjs} adapterLocale='nlNL'>
          <BrowserRouter>
          <Banner />
            <div className='MainLayout'>
              <Routes>
                <Route path="/">
                  <Route index element={<Login />} />
                  <Route path="Home" element={<Home/>} />
                  <Route path="*" element={<Login />} />
                </Route>
              </Routes>
            </div>
          </BrowserRouter>
        </LocalizationProvider>
      </ThemeProvider>
    </React.Fragment>
  );
}

export default App;
