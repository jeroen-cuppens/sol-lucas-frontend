import { configureStore } from "@reduxjs/toolkit";
import popUpReducer from "./slices/popupSlice";
import currentUserReducer from "./slices/currentUserSlice";

export const store = configureStore({
  reducer: {
    popUp: popUpReducer,
    currentUser: currentUserReducer,
  },
});

export type RootState = ReturnType<typeof store.getState>;
export type AppDispatch = typeof store.dispatch;
