import { createSlice, PayloadAction } from "@reduxjs/toolkit";
import { IPopup } from "../../models/IPopup";
import { popupOpties } from "../../common/popupOpties";
import { IUser } from "../../models/IUser";

interface PopupState {
  currentPopup: IPopup;
}

const initialState: PopupState = {
  currentPopup: {type:popupOpties.none, text:""},
};

const popUpSlice = createSlice({
  name: "popUp",
  initialState,
  reducers: {
    changePopup: (state, action: PayloadAction<IPopup>) => {
      state.currentPopup = action.payload;
    },
    clearPopup: (state) => {
      state.currentPopup = {type:popupOpties.none, text:""};
    },
  },
});

// Export acties voor dispatch
export const { changePopup, clearPopup } = popUpSlice.actions;

// Export reducer voor in store
export default popUpSlice.reducer;
