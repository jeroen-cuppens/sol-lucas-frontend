import { createSlice, PayloadAction } from "@reduxjs/toolkit";
import { IUser } from "../../models/IUser";


interface CurrentUserState {
  currentUser: IUser;
}

const initialState: CurrentUserState = {
  currentUser: {address:"",lastName:"",name:"",skills:[]},
};

const currentUserSlice = createSlice({
  name: "currentUser",
  initialState,
  reducers: {
    changeCurrentUser: (state, action: PayloadAction<IUser>) => {
      state.currentUser = action.payload;
    },
    clearCurrentUser: (state) => {
      state.currentUser= {address:"",lastName:"",name:"",skills:[]};
    },
  },
});

// Export acties voor dispatch
export const { changeCurrentUser, clearCurrentUser } = currentUserSlice.actions;

// Export reducer voor in store
export default currentUserSlice.reducer;
