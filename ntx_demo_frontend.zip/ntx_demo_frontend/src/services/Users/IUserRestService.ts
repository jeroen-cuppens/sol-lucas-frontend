import { IUser } from "../../models/IUser"

export interface IUserRestService{
    GetUser(email:string): Promise<IUser>
    GetUsers(): Promise<IUser[]>
    AddUser(body:IUser): Promise<IUser>
}