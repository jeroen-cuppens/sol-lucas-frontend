
import { IUser } from "../../models/IUser";
import { apiBaseUrl } from "../common";
import { IUserRestService } from "./IUserRestService";


export class UserRestService implements IUserRestService {

    private apiMethodBaseUrl = apiBaseUrl + "/User";

    public async GetUser(email:string): Promise<IUser> {

        const sqlQuery = this.apiMethodBaseUrl+"/getUser?email="+encodeURIComponent(email);
        const response = await fetch(sqlQuery, {method:'GET'});

        if(!response.ok){
            if(response.status == 404){
                throw new Error("404");
            }else{
                const message = `${response.status}`;
                throw new Error(message);
            }
        }

        const restult:IUser = await response.json();
        return restult;
    }

    public async GetUsers(): Promise<IUser[]> {

        const sqlQuery = this.apiMethodBaseUrl+"/GetUsers";
        const response = await fetch(sqlQuery, {method:'GET'});

        if(!response.ok){
            if(response.status == 404){
                throw new Error("404");
            }else{
                const message = `${response.status}`;
                throw new Error(message);
            }
        }

        const restult:IUser[] = await response.json();
        return restult;
    }

    public async AddUser(body:IUser): Promise<IUser> {
        
        const sqlQuery = this.apiMethodBaseUrl+"/AddUser";
        const response = await fetch(sqlQuery, {method:'POST', body: JSON.stringify(body), headers: {'Content-Type': 'application/json'}});

        if(!response.ok){
            if(response.status == 404){
                throw new Error("404");
            }else{
                const message = `${response.status}`;
                throw new Error(message);
            }
        }

        const restult:IUser = await response.json();
        return restult;
    }

}