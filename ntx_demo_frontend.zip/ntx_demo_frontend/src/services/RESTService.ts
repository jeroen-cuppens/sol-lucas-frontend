import { IRESTService } from "./IRESTService";

import { IUserRestService } from "./Users/IUserRestService";
import { UserRestService } from "./Users/UserRestService";

export class RESTService implements IRESTService {
    public user:IUserRestService = new UserRestService();
}