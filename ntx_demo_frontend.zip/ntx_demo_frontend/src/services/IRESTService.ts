import {IUserRestService} from "./Users/IUserRestService";


export interface IRESTService {
    user:IUserRestService;
}
