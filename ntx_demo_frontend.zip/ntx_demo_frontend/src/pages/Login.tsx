
import { Box, Button, Card, Grid, Paper, TextField, ThemeProvider, Typography, useTheme } from '@mui/material';
import { ThemeLight } from '../theme';
import "../css/login.css";
import { useTranslation } from 'react-i18next';
import { useNavigate } from 'react-router-dom';
import { Password } from '@mui/icons-material';
import LoginForm from '../components/loginForm';
import RegisterForm from '../components/registerForm';
import { useAppDispatch } from '../store/hooks';
import { changePopup } from '../store/slices/popupSlice';
import { popupOpties } from '../common/popupOpties';

function Login() {
    const theme = useTheme();


    return (
        <ThemeProvider theme={ThemeLight}>
            <div className='mainLayout'>
                <LoginForm/>
                <RegisterForm/>
            </div>
        </ThemeProvider>
    )
}
export default Login;
