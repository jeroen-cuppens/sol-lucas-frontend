
import { Box, Button, Card, Grid, ThemeProvider, Typography, useTheme } from '@mui/material';
import { ThemeLight } from '../theme';
import "../css/home.css";
import { useTranslation } from 'react-i18next';
import { useNavigate } from 'react-router-dom';
import BusinessCard from '../components/businessCard';
import { useAppDispatch, useAppSelector } from '../store/hooks';
import { useEffect, useState } from 'react';
import { changeCurrentUser } from '../store/slices/currentUserSlice';
import { IUser } from '../models/IUser';
import { stringify } from 'querystring';
import { changePopup } from '../store/slices/popupSlice';
import { popupOpties } from '../common/popupOpties';
import { IRESTService } from '../services';
import { RESTService } from '../services/RESTService';

function Home() {
    const theme = useTheme();
    const navigate = useNavigate();
    const { t, i18n } = useTranslation();
    const dispatch = useAppDispatch();
    const service: IRESTService = new RESTService();
    const [user, setUser] = useState<IUser>({address:"",lastName:"",name:"",skills:[]});
    const [users, setUsers] = useState<IUser[]>([]);

    useEffect(() => {
        getCurrentUser();
        GetAllUsers();
    }, []);

    const getCurrentUser = () =>{
        const storedUser = localStorage.getItem("user");
        if (storedUser) {
            try {
                const parsedUser: IUser = JSON.parse(storedUser);
                setUser(parsedUser);
            } catch (err) {
                console.error("Failed to parse user:", err);
            }
        }
    }
    
    const GetAllUsers = async() =>{
        try{
            //authenticate

            const userList:IUser[] = await service.user.GetUsers();

            if(userList != null && userList != undefined){
                setUsers(userList);
            }else{
                throw new Error('no user')
            }


            dispatch(changePopup({type:popupOpties.success, text:"Success"}));

            navigate('/Home');

        }catch{
            dispatch(changePopup({type:popupOpties.error, text:"Something went wrong."}));
        }
    }


    return (
        <ThemeProvider theme={ThemeLight}>
            <h1 className="mainTitle">Networking App</h1>
            <Button variant='contained' >Edit info</Button>
            <div className='mainColumns'>
                <div>
                    <BusinessCard address={user.address} lastName={user.lastName} name={user.name} skills={user.skills}/>
                </div>
                <div>
                    {users.map((user) => (
                        <BusinessCard address={user.address} lastName={user.lastName} name={user.name} skills={user.skills}/>
                    ))}
                </div>
            </div>
        </ThemeProvider>
    )
}
export default Home;
