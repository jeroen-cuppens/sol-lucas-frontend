

export interface ISkill {
    skillId: string,
    skillName:string,
}
