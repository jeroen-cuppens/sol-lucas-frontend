import { popupOpties } from "../common/popupOpties";

export interface IPopup {
    type: popupOpties;
    text: string;
}
