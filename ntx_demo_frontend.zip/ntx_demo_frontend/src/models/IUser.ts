import { ISkill } from "./ISkill";


export interface IUser {
    name:string;
    lastName:string;
    address: string;
    skills: ISkill[];
}
