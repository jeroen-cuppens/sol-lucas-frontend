import { createTheme } from "@mui/material";

const customGreen = "#19ca92";
const customBlue = "#4564e5";
const customWhite = "#FBFAF5";

export const ThemeLight = createTheme({
    palette: {
        mode:"light",
        primary: {
            main: customGreen,
            contrastText: customWhite,
        },
        secondary: {
            main: customBlue,
            contrastText: customWhite
        },
        text:{
            primary: "#12125e",
            secondary: "gray",
        },
        common:{
            white: "#f9fafb"
        },
        background:{
            paper: "#f9fafb"
        }
    },
});

export const ThemeDark = createTheme({
    palette: {
        primary: {
            main: customGreen,
            contrastText: customWhite,
        },
        secondary: {
            main: customBlue,
            contrastText: customWhite
        },
        text:{
            primary: "#12125e",
            secondary: "gray",
        },
        common:{
            white: "#f9fafb"
        },
        background:{
            paper: "#f9fafb"
        }
    }
})